var dojoConfig = {
  async: true,
  isDebug: true,
  parseOnLoad: false,

  packages: [
    {
      name: 'demo',
      location: location.pathname + 'js/demo'
    }
  ]
};
