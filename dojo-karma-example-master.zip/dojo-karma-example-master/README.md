# An example of using Karma on a Dojo project

## Install
1. `brew install phantomjs` - Install phantomjs
2. `npm install -g karma` - Install Karma
3. `npm install -g grunt-cli` - Install grunt command line tools
4. `npm install` - install dependencies
5. `grunt` - rerun tests when source files change
6. `grunt karma:coverage` - run tests and output coverage information

This is originally based off of https://raw.github.com/gmarty/karma-dojo

## Links
