require([
  'demo/app'
], function(app) {
  app.render(dojo.query('body')[0]);
});